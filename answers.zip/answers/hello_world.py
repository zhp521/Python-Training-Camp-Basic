def print_hello_world():
    """
    输出"Hello, World!"
    
    用于学习print函数的基本使用
    """
    print("Hello, World!")